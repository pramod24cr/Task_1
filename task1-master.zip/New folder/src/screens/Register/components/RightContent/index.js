import RightContent from './RightContent';

export default RightContent;
